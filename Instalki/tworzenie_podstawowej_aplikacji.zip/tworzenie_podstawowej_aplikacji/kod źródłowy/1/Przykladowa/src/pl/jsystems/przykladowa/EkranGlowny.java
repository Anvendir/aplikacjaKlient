package pl.jsystems.przykladowa;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class EkranGlowny extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ekran_glowny);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ekran_glowny, menu);
		return true;
	}

}
