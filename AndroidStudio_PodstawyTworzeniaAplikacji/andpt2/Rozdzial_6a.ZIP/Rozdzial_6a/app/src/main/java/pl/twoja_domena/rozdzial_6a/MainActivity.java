package pl.twoja_domena.rozdzial_6a;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import java.util.Calendar;
import java.util.TimeZone;

public class MainActivity extends ActionBarActivity {

    public void kliknieto(View v)
    {
        finish();
    }
    public void data_i_godzina(View v)
    {
        int r, m, d, h, min, s;
        Calendar c = Calendar.getInstance();
        r = c.get(Calendar.YEAR);
        m = c.get(Calendar.MONTH) + 1;
        d = c.get(Calendar.DAY_OF_MONTH);
        h = c.get(Calendar.HOUR_OF_DAY);
        min = c.get(Calendar.MINUTE);
        s = c.get(Calendar.SECOND);

        TextView d_txt = (TextView) findViewById(R.id.textView1);
        d_txt.setText(r + " - " + m + " - " + d);
        TextView t_txt = (TextView) findViewById(R.id.textView2);
        t_txt.setText(h + " : " + min + " : " + s);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
